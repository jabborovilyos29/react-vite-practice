import { combineReducers } from "redux";
import { cardReducer } from "./cardReducer";


export const reducer = combineReducers({
    cardReducer,
})