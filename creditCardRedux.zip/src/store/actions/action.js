export const SVG_SELECT = "SVG_SELECT";
export const COLOR_SELECT = "COLOR_SELECT";
export const FILTER_DATA = "FILTER_DATA";



