import React from "react";
import SvgComponent from "./SvgComponent";

export function MainComponent() {
  return (
    <div className="main__container">
      <SvgComponent />
    </div>
  );
}
