import React from "react";

export function Header() {
  return (
    <header className="header">
      <h2>Welcome</h2>
      <h2>CardDesign</h2>
    </header>
  );
}
